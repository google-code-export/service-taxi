create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = cliente, pg_catalog;

ALTER TABLE ONLY cliente.contatos DROP CONSTRAINT contatos_cliente_cadastro_id_fk;
DROP INDEX cliente.unique_schema_migrations;
ALTER TABLE ONLY cliente.contatos DROP CONSTRAINT contatos_pkey;
ALTER TABLE ONLY cliente.cliente_cadastros DROP CONSTRAINT cliente_cadastros_pkey;
ALTER TABLE cliente.contatos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE cliente.cliente_cadastros ALTER COLUMN id DROP DEFAULT;
DROP TABLE cliente.schema_migrations;
DROP SEQUENCE cliente.contatos_id_seq;
DROP TABLE cliente.contatos;
DROP SEQUENCE cliente.cliente_cadastros_id_seq;
DROP TABLE cliente.cliente_cadastros;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
DROP SCHEMA cliente;
--
-- Name: cliente; Type: SCHEMA; Schema: -; Owner: orlando
--

CREATE SCHEMA cliente;


ALTER SCHEMA cliente OWNER TO orlando;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = cliente, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cliente_cadastros; Type: TABLE; Schema: cliente; Owner: orlando; Tablespace: 
--

CREATE TABLE cliente_cadastros (
    id integer NOT NULL,
    nome character varying(50) NOT NULL,
    endereco character varying(50) NOT NULL,
    cpf character varying(11) NOT NULL,
    cnpj character varying(14) NOT NULL,
    email character varying(50) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE cliente.cliente_cadastros OWNER TO orlando;

--
-- Name: cliente_cadastros_id_seq; Type: SEQUENCE; Schema: cliente; Owner: orlando
--

CREATE SEQUENCE cliente_cadastros_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cliente.cliente_cadastros_id_seq OWNER TO orlando;

--
-- Name: cliente_cadastros_id_seq; Type: SEQUENCE OWNED BY; Schema: cliente; Owner: orlando
--

ALTER SEQUENCE cliente_cadastros_id_seq OWNED BY cliente_cadastros.id;


--
-- Name: cliente_cadastros_id_seq; Type: SEQUENCE SET; Schema: cliente; Owner: orlando
--

SELECT pg_catalog.setval('cliente_cadastros_id_seq', 27, true);


--
-- Name: contatos; Type: TABLE; Schema: cliente; Owner: orlando; Tablespace: 
--

CREATE TABLE contatos (
    id integer NOT NULL,
    telefone character varying(11) NOT NULL,
    celular character varying(11) NOT NULL,
    cliente_cadastro_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE cliente.contatos OWNER TO orlando;

--
-- Name: contatos_id_seq; Type: SEQUENCE; Schema: cliente; Owner: orlando
--

CREATE SEQUENCE contatos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cliente.contatos_id_seq OWNER TO orlando;

--
-- Name: contatos_id_seq; Type: SEQUENCE OWNED BY; Schema: cliente; Owner: orlando
--

ALTER SEQUENCE contatos_id_seq OWNED BY contatos.id;


--
-- Name: contatos_id_seq; Type: SEQUENCE SET; Schema: cliente; Owner: orlando
--

SELECT pg_catalog.setval('contatos_id_seq', 19, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: cliente; Owner: orlando; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE cliente.schema_migrations OWNER TO orlando;

--
-- Name: id; Type: DEFAULT; Schema: cliente; Owner: orlando
--

ALTER TABLE cliente_cadastros ALTER COLUMN id SET DEFAULT nextval('cliente_cadastros_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: cliente; Owner: orlando
--

ALTER TABLE contatos ALTER COLUMN id SET DEFAULT nextval('contatos_id_seq'::regclass);


--
-- Data for Name: cliente_cadastros; Type: TABLE DATA; Schema: cliente; Owner: orlando
--

COPY cliente_cadastros (id, nome, endereco, cpf, cnpj, email, created_at, updated_at) FROM stdin;
\.
copy cliente_cadastros (id, nome, endereco, cpf, cnpj, email, created_at, updated_at)  from '$$PATH$$/1797.dat' ;
--
-- Data for Name: contatos; Type: TABLE DATA; Schema: cliente; Owner: orlando
--

COPY contatos (id, telefone, celular, cliente_cadastro_id, created_at, updated_at) FROM stdin;
\.
copy contatos (id, telefone, celular, cliente_cadastro_id, created_at, updated_at)  from '$$PATH$$/1798.dat' ;
--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: cliente; Owner: orlando
--

COPY schema_migrations (version) FROM stdin;
\.
copy schema_migrations (version)  from '$$PATH$$/1796.dat' ;
--
-- Name: cliente_cadastros_pkey; Type: CONSTRAINT; Schema: cliente; Owner: orlando; Tablespace: 
--

ALTER TABLE ONLY cliente_cadastros
    ADD CONSTRAINT cliente_cadastros_pkey PRIMARY KEY (id);


--
-- Name: contatos_pkey; Type: CONSTRAINT; Schema: cliente; Owner: orlando; Tablespace: 
--

ALTER TABLE ONLY contatos
    ADD CONSTRAINT contatos_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: cliente; Owner: orlando; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: contatos_cliente_cadastro_id_fk; Type: FK CONSTRAINT; Schema: cliente; Owner: orlando
--

ALTER TABLE ONLY contatos
    ADD CONSTRAINT contatos_cliente_cadastro_id_fk FOREIGN KEY (cliente_cadastro_id) REFERENCES cliente_cadastros(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

